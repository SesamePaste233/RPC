#pragma once
#include <iostream>
#include <fstream>
#include <vector>
#include <map>
#include <iomanip>
#include <functional>

#include <Eigen/Core>
#include <Eigen/Dense>